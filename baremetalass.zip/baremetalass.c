/*
Name:Anand sai kumar.G
Date:23-09-2024
Description:
Sample I/P:
Sample O/P:
*/
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#define HEAP_SIZE (128 * 1024) // 128KB
#define BLOCK_SIZE (1024) // Minimum block size is 1KB

typedef struct Block {
    size_t size;
    bool allocated;
    struct Block *next;
} Block;

static uint8_t heap[HEAP_SIZE];
static Block *freeList = NULL;
static void *lastMalloc = NULL;
static void *lastFree = NULL;

void initialize_heap() {
    freeList = (Block *)heap;
    freeList->size = HEAP_SIZE - sizeof(Block);
    freeList->allocated = false;
    freeList->next = NULL;
}
void *malloc(size_t size) {
    if (size == 0 || lastMalloc != NULL) {
        return NULL; // Cannot allocate if size is 0 or if last malloc was not freed
    }
    // Adjust the size to fit the minimum block size
    size = (size + sizeof(Block) + BLOCK_SIZE - 1) & ~(BLOCK_SIZE - 1); // Align to BLOCK_SIZE

    Block *current = freeList;
    Block *bestFit = NULL;
    Block *prev = NULL;
    Block *bestPrev = NULL;
    // Find the best fit block
    while (current != NULL) {
        if (!current->allocated && current->size >= size) {
            if (bestFit == NULL || current->size < bestFit->size) {
                bestFit = current;
                bestPrev = prev;
            }
        }
        prev = current;
        current = current->next;
    }
    // If no suitable block is found
    if (bestFit == NULL) {
        return NULL;
    }
    // Split the block if it's larger than needed
    if (bestFit->size >= size + sizeof(Block) + BLOCK_SIZE) {
        Block *newBlock = (Block *)((uint8_t *)bestFit + sizeof(Block) + size);
        newBlock->size = bestFit->size - size - sizeof(Block);
        newBlock->allocated = false;
        newBlock->next = bestFit->next;

        if (bestPrev == NULL) {
            freeList = newBlock; // Adjust head of the free list
        } else {
            bestPrev->next = newBlock; // Adjust the previous block's next pointer
        }
        bestFit->size = size;
        bestFit->allocated = true;
        bestFit->next = NULL; // Clear next pointer
    } else {
        // No need to split
        bestFit->allocated = true;
        if (bestPrev == NULL) {
            freeList = bestFit->next; // Adjust head of the free list
        } else {
            bestPrev->next = bestFit->next; // Remove from free list
        }
    }
    lastMalloc = (void *)((uint8_t *)bestFit + sizeof(Block));
    return lastMalloc; // Return pointer to the memory
}

void free(void *ptr) {
    if (ptr == NULL || lastFree != NULL || ptr < (void *)heap || ptr >= (void *)(heap + HEAP_SIZE)) {
        return; // Invalid free operation
    }
    Block *blockToFree = (Block *)((uint8_t *)ptr - sizeof(Block));
    blockToFree->allocated = false;
    // Add block back to free list
    blockToFree->next = freeList;
    freeList = blockToFree;
    lastFree = ptr; // Remember the last freed pointer
}
// Example usage
int main() {
    initialize_heap();
    void *p1 = malloc(sizeof(int) * 128);
    printf("Allocated p1: %p\n", p1);
    void *p2 = malloc(sizeof(uint8_t) * 1000);
    printf("Allocated p2: %p\n", p2);
    void *p3 = malloc(128 * 8 * 1024);
    printf("Allocated p3: %p\n", p3);
    free(p1);
    printf("Freed p1\n");
    free(p2);
    printf("Freed p2\n");
    free(p3);
    printf("Freed p3\n");
    return 0;
}

